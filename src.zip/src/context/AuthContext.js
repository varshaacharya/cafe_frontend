import { createContext, useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import ApplicationStore from "../utils/localStorageUtil";

export const AuthContext = createContext({
     user:null,
     login:(user)=>{},
     logout:()=>{}
});

export const AuthContextProvider = ({children}) => {
    const [user, setUser] = useState('');
    const [userRole, setUserRole] = useState('');
    const [loggedIn, setLoggedIn] = useState(false);
    const [email,setEmail]=useState('');    
    const navigate = useNavigate();

    const Login = userData => { 
        setUserRole(userData.userRole); 
        setEmail(userData.email);       
        ApplicationStore().setStorage('token',userData.userToken);
        ApplicationStore().setStorage('userRole',userData.userRole);
        ApplicationStore().setStorage('email',userData.email);
        setLoggedIn(true);
    }

    const Logout = () => {
        const data = {email:user}; 
        console.log("loggd out");
        ApplicationStore().removeStorage('token');
        ApplicationStore().removeStorage('userRole');
        ApplicationStore().removeStorage('email');
        setUser(null);
        setLoggedIn(false);
        navigate("/Login");
    }

    return  (
        <AuthContext.Provider value={{ user, Login, userRole, loggedIn, Logout,email }}>
            {children}
        </AuthContext.Provider>
    )
    
}

export function useAuthContext(){
    const {user, Login, userRole, loggedIn, Logout,email} =  useContext(AuthContext);
    return {user, Login, userRole, loggedIn, Logout,email};
}










