
import { Link, Outlet } from "react-router-dom";
function AdminDashboard(){

    return(
        <>hello
        <Outlet />
        </>
    )
};
export default AdminDashboard;