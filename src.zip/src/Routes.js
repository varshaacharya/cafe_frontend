import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Displayreg from './pages/components/Register/Displayreg';
import Login from './pages/components/Login/Login';
import Registration from './pages/components/Login/Registration';
import AdminDashboard from './pages/components/Dashboard/AdminDashboard';
import ProtectedRoutes from './protectedRoutes';
import Dropdown from './pages/components/Dropdown';
import ChangePassword from './pages/components/Login/ChangePassword';




const MainRoutes = () => {
    return (
        <Routes>
          {/* <Route path='/Dropdown' element={<Dropdown/>}></Route> */}
          <Route path="/login" element={ <Login />} />
          <Route path="/Registration" element={ <Registration />} />
          <Route path="/ChangePassword" element={<ChangePassword/>}/>
          <Route element={<ProtectedRoutes/>}>
          <Route path="/" element={<AdminDashboard/>}> 
          <Route path="/Dropdown" element={<Dropdown/>}/>
          <Route path="/ChangePassword" element={<ChangePassword/>}/>
         </Route>
          </Route>
        </Routes>
    );
}

export default MainRoutes;