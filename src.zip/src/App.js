import logo from './logo.svg';
import './App.css';
import MainRoutes from './Routes';

function App() { 
  return (
    <div className="App">          
        <MainRoutes />
    </div>
  );
}

export default App;
